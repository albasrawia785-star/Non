/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from "react";
import { motion } from "motion/react";
import {
  TrendingUp,
  DollarSign,
  AlertTriangle,
  PackageX,
  Pill,
  ShoppingCart,
  Plus,
  ArrowLeft,
  Calendar,
  Layers,
  FileSpreadsheet,
  DatabaseBackup,
  Settings
} from "lucide-react";
import { IndexedDBService } from "../db/indexedDB";
import { Product, SaleInvoice, Category } from "../types";

interface DashboardViewProps {
  onNavigate: (view: string) => void;
  currency: string;
}

export default function DashboardView({ onNavigate, currency }: DashboardViewProps) {
  const [stats, setStats] = useState({
    todaySales: 0,
    todayProfit: 0,
    expiredCount: 0,
    lowStockCount: 0,
    nearExpiryCount: 0,
    totalInventoryValue: 0,
    totalProductsCount: 0,
    totalCategoriesCount: 0
  });

  const [criticalAlerts, setCriticalAlerts] = useState<{ id: string; name: string; sciName: string; type: "expired" | "low_stock"; value: string }[]>([]);
  const [recentSales, setRecentSales] = useState<SaleInvoice[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadDashboardData() {
      try {
        setLoading(true);
        const products = await IndexedDBService.getAll<Product>("products");
        const sales = await IndexedDBService.getAll<SaleInvoice>("sales");
        const categories = await IndexedDBService.getAll<Category>("categories");

        const todayStr = new Date().toISOString().split("T")[0];
        const thirtyDaysLater = new Date();
        thirtyDaysLater.setDate(thirtyDaysLater.getDate() + 30);
        const thirtyDaysStr = thirtyDaysLater.toISOString().split("T")[0];

        // 1. Calculate stats
        let todaySales = 0;
        let todayProfit = 0;
        let expiredCount = 0;
        let lowStockCount = 0;
        let nearExpiryCount = 0;
        let totalInventoryValue = 0;

        // Fetch buyPrices map for profit calculations
        const buyPricesMap = new Map<string, number>();
        products.forEach((p) => {
          buyPricesMap.set(p.id, p.buyPrice);
          totalInventoryValue += (p.quantity * p.buyPrice);

          if (p.expirationDate <= todayStr) {
            expiredCount++;
          } else if (p.expirationDate <= thirtyDaysStr) {
            nearExpiryCount++;
          }

          if (p.quantity <= p.minStock) {
            lowStockCount++;
          }
        });

        const todaySalesList = sales.filter((s) => s.date.startsWith(todayStr));
        todaySalesList.forEach((s) => {
          todaySales += s.total;
          s.items.forEach((item) => {
            const buyPrice = buyPricesMap.get(item.productId) || 0;
            const itemProfit = (item.price - buyPrice) * item.quantity;
            todayProfit += itemProfit;
          });
        });

        setStats({
          todaySales,
          todayProfit,
          expiredCount,
          lowStockCount,
          nearExpiryCount,
          totalInventoryValue,
          totalProductsCount: products.length,
          totalCategoriesCount: categories.length
        });

        // 2. Critical Alerts list (up to 5 items)
        const alertsList: typeof criticalAlerts = [];
        for (const p of products) {
          if (alertsList.length >= 5) break;
          if (p.expirationDate <= todayStr) {
            alertsList.push({
              id: p.id,
              name: p.commercialName,
              sciName: p.scientificName,
              type: "expired",
              value: `منتهي الصلاحية منذ ${p.expirationDate}`
            });
          } else if (p.quantity <= p.minStock) {
            alertsList.push({
              id: p.id,
              name: p.commercialName,
              sciName: p.scientificName,
              type: "low_stock",
              value: p.quantity === 0 ? "نفذ بالكامل من المخزن" : `كمية حرجة متبقية: ${p.quantity} علبة`
            });
          }
        }
        setCriticalAlerts(alertsList);

        // 3. Recent Sales (up to 5 items)
        const sortedSales = [...sales].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
        setRecentSales(sortedSales.slice(0, 5));
      } catch (err) {
        console.error("Failed to load dashboard statistics:", err);
      } finally {
        setLoading(false);
      }
    }

    loadDashboardData();
  }, []);

  const formatPrice = (val: number) => {
    return val.toLocaleString("ar-IQ") + " " + currency;
  };

  const statCards = [
    {
      title: "مبيعات اليوم",
      value: formatPrice(stats.todaySales),
      icon: TrendingUp,
      color: "text-emerald-600 dark:text-emerald-400 bg-emerald-50/70 dark:bg-emerald-950/20 border-emerald-100 dark:border-emerald-900/50"
    },
    {
      title: "أرباح اليوم التقديرية",
      value: formatPrice(stats.todayProfit),
      icon: DollarSign,
      color: "text-blue-600 dark:text-blue-400 bg-blue-50/70 dark:bg-blue-950/20 border-blue-100 dark:border-blue-900/50"
    },
    {
      title: "قيمة المخزون الكلية",
      value: formatPrice(stats.totalInventoryValue),
      icon: Pill,
      color: "text-indigo-600 dark:text-indigo-400 bg-indigo-50/70 dark:bg-indigo-950/20 border-indigo-100 dark:border-indigo-900/50"
    },
    {
      title: "أدوية منتهية الصلاحية",
      value: `${stats.expiredCount} دواء`,
      icon: PackageX,
      color: "text-rose-600 dark:text-rose-400 bg-rose-50/70 dark:bg-rose-950/20 border-rose-100 dark:border-rose-900/50",
      alert: stats.expiredCount > 0,
      view: "products"
    },
    {
      title: "نقص حرج / كمية منخفضة",
      value: `${stats.lowStockCount} دواء`,
      icon: AlertTriangle,
      color: "text-amber-600 dark:text-amber-400 bg-amber-50/70 dark:bg-amber-950/20 border-amber-100 dark:border-amber-900/50",
      alert: stats.lowStockCount > 0,
      view: "products"
    },
    {
      title: "قريب الانتهاء (30 يوم)",
      value: `${stats.nearExpiryCount} دواء`,
      icon: Calendar,
      color: "text-purple-600 dark:text-purple-400 bg-purple-50/70 dark:bg-purple-950/20 border-purple-100 dark:border-purple-900/50",
      alert: stats.nearExpiryCount > 0,
      view: "products"
    }
  ];

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh]">
        <div className="w-10 h-10 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin mb-4" />
        <p className="text-sm text-slate-500 font-sans">جاري تحميل لوحة التحكم...</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Welcome Header */}
      <div className="flex flex-col gap-1 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100">مرحباً بك في صيدلي برو 👋</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">إليك نظرة عامة سريعة على مبيعات ومخزون صيدليتك اليوم.</p>
        </div>
        <div className="flex items-center gap-2 mt-2 md:mt-0 px-4 py-2 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 text-xs font-mono self-start md:self-auto">
          <Calendar className="w-4 h-4 text-emerald-500" />
          <span>{new Date().toLocaleDateString("ar-IQ", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}</span>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {statCards.map((card, i) => {
          const Icon = card.icon;
          return (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              onClick={() => card.view && onNavigate(card.view)}
              className={`p-5 rounded-2xl border flex items-center justify-between shadow-xs transition-all duration-200 ${
                card.view ? "cursor-pointer hover:shadow-md hover:-translate-y-0.5" : ""
              } ${card.color}`}
            >
              <div className="space-y-1">
                <span className="text-xs font-medium opacity-80">{card.title}</span>
                <p className="text-xl font-bold tracking-tight">{card.value}</p>
              </div>
              <div className="p-3 rounded-xl bg-white/60 dark:bg-slate-900/60 shadow-xs">
                <Icon className="w-6 h-6 shrink-0" />
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Quick Launchpad & Alerts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Launchpad (2 columns on desktop) */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800">
            <h2 className="text-sm font-semibold text-slate-800 dark:text-slate-100 mb-4 flex items-center gap-2">
              <Layers className="w-4 h-4 text-emerald-500" />
              <span>الوصول السريع للعمليات</span>
            </h2>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              <button
                id="quick-pos"
                onClick={() => onNavigate("pos")}
                className="p-4 rounded-xl border border-emerald-100 dark:border-emerald-900 bg-emerald-50/30 dark:bg-emerald-950/10 hover:bg-emerald-50 dark:hover:bg-emerald-950/30 text-emerald-700 dark:text-emerald-400 flex flex-col items-center justify-center text-center gap-2 transition-all cursor-pointer group"
              >
                <div className="p-3 rounded-lg bg-emerald-100/60 dark:bg-emerald-950 group-hover:scale-110 transition-transform">
                  <ShoppingCart className="w-5 h-5" />
                </div>
                <span className="text-xs font-semibold">شاشة البيع السريع</span>
              </button>

              <button
                id="quick-add-product"
                onClick={() => onNavigate("products")}
                className="p-4 rounded-xl border border-slate-150 dark:border-slate-800 bg-slate-50/20 hover:bg-slate-50 dark:hover:bg-slate-800/40 text-slate-700 dark:text-slate-300 flex flex-col items-center justify-center text-center gap-2 transition-all cursor-pointer group"
              >
                <div className="p-3 rounded-lg bg-slate-100 dark:bg-slate-800 group-hover:scale-110 transition-transform">
                  <Plus className="w-5 h-5" />
                </div>
                <span className="text-xs font-semibold">إضافة دواء جديد</span>
              </button>

              <button
                onClick={() => onNavigate("inventory")}
                className="p-4 rounded-xl border border-slate-150 dark:border-slate-800 bg-slate-50/20 hover:bg-slate-50 dark:hover:bg-slate-800/40 text-slate-700 dark:text-slate-300 flex flex-col items-center justify-center text-center gap-2 transition-all cursor-pointer group"
              >
                <div className="p-3 rounded-lg bg-slate-100 dark:bg-slate-800 group-hover:scale-110 transition-transform">
                  <Pill className="w-5 h-5" />
                </div>
                <span className="text-xs font-semibold">جرد المخزن والرفوف</span>
              </button>

              <button
                onClick={() => onNavigate("reports")}
                className="p-4 rounded-xl border border-slate-150 dark:border-slate-800 bg-slate-50/20 hover:bg-slate-50 dark:hover:bg-slate-800/40 text-slate-700 dark:text-slate-300 flex flex-col items-center justify-center text-center gap-2 transition-all cursor-pointer group"
              >
                <div className="p-3 rounded-lg bg-slate-100 dark:bg-slate-800 group-hover:scale-110 transition-transform">
                  <FileSpreadsheet className="w-5 h-5" />
                </div>
                <span className="text-xs font-semibold">عرض التقارير والأرباح</span>
              </button>

              <button
                onClick={() => onNavigate("backup")}
                className="p-4 rounded-xl border border-slate-150 dark:border-slate-800 bg-slate-50/20 hover:bg-slate-50 dark:hover:bg-slate-800/40 text-slate-700 dark:text-slate-300 flex flex-col items-center justify-center text-center gap-2 transition-all cursor-pointer group"
              >
                <div className="p-3 rounded-lg bg-slate-100 dark:bg-slate-800 group-hover:scale-110 transition-transform">
                  <DatabaseBackup className="w-5 h-5" />
                </div>
                <span className="text-xs font-semibold">النسخ الاحتياطي والدمج</span>
              </button>

              <button
                onClick={() => onNavigate("settings")}
                className="p-4 rounded-xl border border-slate-150 dark:border-slate-800 bg-slate-50/20 hover:bg-slate-50 dark:hover:bg-slate-800/40 text-slate-700 dark:text-slate-300 flex flex-col items-center justify-center text-center gap-2 transition-all cursor-pointer group"
              >
                <div className="p-3 rounded-lg bg-slate-100 dark:bg-slate-800 group-hover:scale-110 transition-transform">
                  <Settings className="w-5 h-5" />
                </div>
                <span className="text-xs font-semibold">إعدادات الصيدلية</span>
              </button>
            </div>
          </div>

          {/* Today's Recent Sales list */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-sm font-semibold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                <ShoppingCart className="w-4 h-4 text-emerald-500" />
                <span>آخر مبيعات اليوم</span>
              </h2>
              <button
                onClick={() => onNavigate("invoices")}
                className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <span>عرض الكل</span>
                <ArrowLeft className="w-3.5 h-3.5" />
              </button>
            </div>

            {recentSales.length === 0 ? (
              <div className="p-6 text-center text-sm text-slate-400 dark:text-slate-500 bg-slate-50/50 dark:bg-slate-800/20 rounded-xl">
                لا توجد مبيعات مسجلة لليوم حتى الآن.
              </div>
            ) : (
              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                {recentSales.map((invoice) => (
                  <div key={invoice.id} className="py-3.5 flex items-center justify-between text-sm">
                    <div>
                      <p className="font-semibold text-slate-800 dark:text-slate-200 font-mono text-xs">{invoice.invoiceNumber}</p>
                      <p className="text-xs text-slate-400 mt-0.5">
                        {invoice.items.length} أصناف • {new Date(invoice.date).toLocaleTimeString("ar-IQ", { hour: "numeric", minute: "2-digit" })}
                      </p>
                    </div>
                    <div className="text-left">
                      <p className="font-bold text-slate-900 dark:text-slate-100">{formatPrice(invoice.total)}</p>
                      <span className="text-[10px] text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-1.5 py-0.5 rounded-md font-medium">
                        مكتملة
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Alerts Column (1 column on desktop) */}
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 h-full">
            <h2 className="text-sm font-semibold text-slate-800 dark:text-slate-100 mb-4 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-500" />
              <span>تنبيهات عاجلة</span>
            </h2>

            {criticalAlerts.length === 0 ? (
              <div className="h-48 flex flex-col items-center justify-center text-center p-4 bg-emerald-50/20 dark:bg-emerald-950/10 rounded-2xl border border-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                <ShieldCheck className="w-10 h-10 mb-2" />
                <p className="text-xs font-semibold">كل شيء ممتاز!</p>
                <p className="text-[10px] opacity-80 mt-1">لا توجد أدوية منتهية الصلاحية أو نقص حرج في الكميات.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {criticalAlerts.map((alert, i) => (
                  <div
                    key={i}
                    className={`p-3.5 rounded-xl border flex gap-3 text-xs leading-relaxed ${
                      alert.type === "expired"
                        ? "bg-rose-50/40 dark:bg-rose-950/10 border-rose-100 dark:border-rose-900/30 text-rose-800 dark:text-rose-300"
                        : "bg-amber-50/40 dark:bg-amber-950/10 border-amber-100 dark:border-amber-900/30 text-amber-800 dark:text-amber-300"
                    }`}
                  >
                    <div className="shrink-0 mt-0.5">
                      {alert.type === "expired" ? (
                        <PackageX className="w-4 h-4 text-rose-500" />
                      ) : (
                        <AlertTriangle className="w-4 h-4 text-amber-500" />
                      )}
                    </div>
                    <div className="flex-1 space-y-1">
                      <p className="font-bold">{alert.name}</p>
                      <p className="text-[10px] opacity-75 truncate">{alert.sciName}</p>
                      <span className="inline-block px-2 py-0.5 rounded-md bg-white/60 dark:bg-slate-900/40 font-semibold font-sans mt-1">
                        {alert.value}
                      </span>
                    </div>
                  </div>
                ))}
                <button
                  onClick={() => onNavigate("inventory")}
                  className="w-full mt-2 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 text-slate-700 dark:text-slate-300 text-xs font-semibold text-center cursor-pointer transition-colors"
                >
                  معالجة وحل التنبيهات
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function ShieldCheck(props: any) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
      <path d="m9 12 2 2 4-4" />
    </svg>
  );
}
