/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Tags, Plus, Pencil, Trash2, Search, X, CheckCircle, AlertTriangle } from "lucide-react";
import { IndexedDBService } from "../db/indexedDB";
import { Category, Product } from "../types";

export default function CategoriesView() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  // Modal / Form States
  const [showModal, setShowModal] = useState(false);
  const [editingCat, setEditingCat] = useState<Category | null>(null);
  const [catName, setCatName] = useState("");
  const [catDesc, setCatDesc] = useState("");

  // Expanded Categories
  const [expandedCatId, setExpandedCatId] = useState<string | null>(null);

  // Edit / Delete Drug states inside categories
  const [editingDrug, setEditingDrug] = useState<Product | null>(null);
  const [drugCommName, setDrugCommName] = useState("");
  const [drugSciName, setDrugSciName] = useState("");
  const [drugManufacturer, setDrugManufacturer] = useState("");
  const [showDrugModal, setShowDrugModal] = useState(false);
  const [showDrugDeleteConfirm, setShowDrugDeleteConfirm] = useState<Product | null>(null);

  const openEditDrugModal = (prod: Product) => {
    setEditingDrug(prod);
    setDrugCommName(prod.commercialName);
    setDrugSciName(prod.scientificName);
    setDrugManufacturer(prod.manufacturer);
    setShowDrugModal(true);
  };

  const handleSaveDrug = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingDrug || !drugCommName.trim() || !drugSciName.trim()) return;

    try {
      const updated: Product = {
        ...editingDrug,
        commercialName: drugCommName,
        scientificName: drugSciName,
        manufacturer: drugManufacturer
      };

      await IndexedDBService.update("products", updated);
      showToast("تم تعديل معلومات الدواء داخل الفئة بنجاح");
      setShowDrugModal(false);
      loadData();
    } catch (err) {
      console.error(err);
      showToast("فشلت عملية تعديل الدواء", "error");
    }
  };

  const handleAttemptDeleteDrug = (prod: Product) => {
    setShowDrugDeleteConfirm(prod);
  };

  const handleConfirmDeleteDrug = async () => {
    if (!showDrugDeleteConfirm) return;

    try {
      await IndexedDBService.delete("products", showDrugDeleteConfirm.id);
      showToast(`تم حذف الدواء (${showDrugDeleteConfirm.commercialName}) من النظام بنجاح`);
      setShowDrugDeleteConfirm(null);
      loadData();
    } catch (err) {
      console.error(err);
      showToast("فشلت عملية حذف الدواء", "error");
    }
  };

  // Alert State for forbidden deletion
  const [forbiddenDelete, setForbiddenDelete] = useState<{ catName: string; count: number } | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<Category | null>(null);

  // Toast
  const [toast, setToast] = useState<{ text: string; type: "success" | "error" } | null>(null);

  const showToast = (text: string, type: "success" | "error" = "success") => {
    setToast({ text, type });
    setTimeout(() => setToast(null), 3000);
  };

  const loadData = async () => {
    setLoading(true);
    try {
      const cats = await IndexedDBService.getAll<Category>("categories");
      const prods = await IndexedDBService.getAll<Product>("products");
      setCategories(cats);
      setProducts(prods);
    } catch (err) {
      console.error(err);
      showToast("خطأ أثناء جلب البيانات", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const openAddModal = () => {
    setEditingCat(null);
    setCatName("");
    setCatDesc("");
    setShowModal(true);
  };

  const openEditModal = (cat: Category) => {
    setEditingCat(cat);
    setCatName(cat.name);
    setCatDesc(cat.description || "");
    setShowModal(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!catName.trim()) return;

    try {
      const catData: Category = {
        id: editingCat ? editingCat.id : `cat-${Date.now()}`,
        name: catName,
        description: catDesc,
      };

      if (editingCat) {
        await IndexedDBService.update("categories", catData);
        showToast("تم تحديث معلومات الفئة بنجاح");
      } else {
        await IndexedDBService.add("categories", catData);
        showToast("تمت إضافة الفئة الجديدة بنجاح");
      }

      setShowModal(false);
      loadData();
    } catch (err) {
      console.error(err);
      showToast("فشلت عملية الحفظ", "error");
    }
  };

  const handleAttemptDelete = (cat: Category) => {
    // Count products inside this category
    const productsInCatCount = products.filter((p) => p.categoryId === cat.id).length;

    if (productsInCatCount > 0) {
      setForbiddenDelete({
        catName: cat.name,
        count: productsInCatCount,
      });
    } else {
      setShowDeleteConfirm(cat);
    }
  };

  const handleConfirmDelete = async () => {
    if (!showDeleteConfirm) return;

    try {
      await IndexedDBService.delete("categories", showDeleteConfirm.id);
      showToast(`تم حذف الفئة (${showDeleteConfirm.name}) بنجاح`);
      setShowDeleteConfirm(null);
      loadData();
    } catch (err) {
      console.error(err);
      showToast("فشلت عملية حذف الفئة", "error");
    }
  };

  // Get product count for a category
  const getProductCount = (catId: string) => {
    return products.filter((p) => p.categoryId === catId).length;
  };

  const filteredCategories = categories.filter(
    (cat) =>
      (cat.name || "").toLowerCase().includes((search || "").toLowerCase()) ||
      ((cat.description || "").toLowerCase().includes((search || "").toLowerCase()))
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100 font-sans">إدارة فئات الأدوية</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 font-sans">تصنيف وترتيب الأدوية في مجموعات مخصصة لتسهيل عمليات البيع والجرد.</p>
        </div>
        <button
          onClick={openAddModal}
          className="flex items-center justify-center gap-1.5 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-md transition-colors cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>إضافة فئة جديدة</span>
        </button>
      </div>

      {/* Search Bar */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-between">
        <div className="relative w-full max-w-sm">
          <input
            type="text"
            placeholder="ابحث عن الفئات بالاسم أو الوصف..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pr-9 pl-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
          />
          <Search className="absolute right-3 top-2.5 w-4 h-4 text-slate-400" />
        </div>
        <span className="text-xs font-mono text-slate-400">إجمالي الفئات: {categories.length}</span>
      </div>

      {/* Categories Grid */}
      {loading ? (
        <div className="flex flex-col items-center justify-center py-20">
          <div className="w-8 h-8 border-3 border-emerald-500 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : filteredCategories.length === 0 ? (
        <div className="p-12 text-center text-slate-400 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl">
          لا توجد فئات دوائية مسجلة مطابقة للبحث.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredCategories.map((cat) => {
            const prodCount = getProductCount(cat.id);
            return (
              <div
                key={cat.id}
                className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <h3 className="font-bold text-slate-850 dark:text-slate-100 text-sm">{cat.name}</h3>
                    <span className="bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 px-2 py-0.5 rounded-full text-[10px] font-bold font-mono">
                      {prodCount} دواء
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed mb-3">
                    {cat.description || "لا يوجد وصف لهذه الفئة الدوائية."}
                  </p>

                  {/* Toggle Medicines Button */}
                  <button
                    onClick={() => setExpandedCatId(expandedCatId === cat.id ? null : cat.id)}
                    className="w-full text-right mb-4 text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    {expandedCatId === cat.id ? "▲ إخفاء قائمة أدوية الفئة" : "▼ عرض وتعديل أدوية هذه الفئة"}
                  </button>

                  {/* Accordion List of medicines inside the Category */}
                  {expandedCatId === cat.id && (
                    <div className="mb-4 p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-150 dark:border-slate-800 space-y-2">
                      <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-700 pb-1.5 mb-2">
                        <span className="text-[11px] font-bold text-slate-600 dark:text-slate-400">اسم الدواء العلمي والتجاري</span>
                        <span className="text-[10px] text-slate-400">إجراءات سريعة</span>
                      </div>
                      {products.filter((p) => p.categoryId === cat.id).length === 0 ? (
                        <p className="text-[10px] text-slate-400 text-center py-2">لا توجد أدوية مضافة حالياً في هذه الفئة.</p>
                      ) : (
                        <div className="max-h-52 overflow-y-auto space-y-2 divide-y divide-slate-100 dark:divide-slate-800 pr-0.5 text-right">
                          {products
                            .filter((p) => p.categoryId === cat.id)
                            .map((prod, idx) => (
                              <div key={prod.id} className={`flex items-center justify-between gap-2 ${idx > 0 ? "pt-2" : ""}`}>
                                <div className="min-w-0 flex-1 text-right">
                                  <div className="flex items-center gap-1">
                                    <span className="font-bold text-slate-800 dark:text-slate-200 text-xs truncate">{prod.commercialName}</span>
                                    {prod.dosageForm && (
                                      <span className="text-[9px] bg-slate-200 dark:bg-slate-750 text-slate-600 dark:text-slate-400 px-1 rounded font-medium">
                                        {prod.dosageForm}
                                      </span>
                                    )}
                                  </div>
                                  <p className="text-[10px] text-slate-400 dark:text-slate-500 italic truncate">{prod.scientificName}</p>
                                </div>
                                <div className="flex items-center gap-0.5 shrink-0">
                                  <button
                                    onClick={() => openEditDrugModal(prod)}
                                    className="p-1 rounded hover:bg-slate-200 dark:hover:bg-slate-750 text-slate-500 hover:text-emerald-600 cursor-pointer transition-colors"
                                    title="تعديل اسم الدواء"
                                  >
                                    <Pencil className="w-3.5 h-3.5" />
                                  </button>
                                  <button
                                    onClick={() => handleAttemptDeleteDrug(prod)}
                                    className="p-1 rounded hover:bg-rose-50 dark:hover:bg-rose-950/20 text-slate-500 hover:text-rose-600 cursor-pointer transition-colors"
                                    title="حذف الدواء"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              </div>
                            ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-2 border-t border-slate-100 dark:border-slate-800 pt-3">
                  <button
                    onClick={() => openEditModal(cat)}
                    className="flex-1 py-1.5 px-3 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 text-xs font-semibold hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <Pencil className="w-3.5 h-3.5" />
                    <span>تعديل الفئة</span>
                  </button>
                  <button
                    onClick={() => handleAttemptDelete(cat)}
                    className="py-1.5 px-3 rounded-lg border border-rose-200 hover:bg-rose-50 text-rose-600 text-xs font-semibold transition-colors flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>حذف الفئة</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* --- ADD / EDIT MODAL --- */}
      <AnimatePresence>
        {showModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 w-full max-w-md shadow-2xl"
            >
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3 mb-4">
                <h3 className="font-bold text-slate-800 dark:text-slate-100 text-base">
                  {editingCat ? "تعديل الفئة الدوائية" : "إضافة فئة أدوية جديدة"}
                </h3>
                <button
                  onClick={() => setShowModal(false)}
                  className="p-1 rounded-lg hover:bg-slate-100 text-slate-500"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSave} className="space-y-4 text-xs font-sans">
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">اسم الفئة (مطلوب):</label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: المضادات الحيوية، أدوية الضغط..."
                    value={catName}
                    onChange={(e) => setCatName(e.target.value)}
                    className="w-full py-2.5 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">وصف موجز للفئة:</label>
                  <textarea
                    rows={3}
                    placeholder="توضيح عام لنوع الأدوية التابعة لهذه الفئة..."
                    value={catDesc}
                    onChange={(e) => setCatDesc(e.target.value)}
                    className="w-full py-2 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-emerald-500 font-sans"
                  />
                </div>

                <div className="flex items-center gap-3 pt-2 justify-end">
                  <button
                    type="button"
                    onClick={() => setShowModal(false)}
                    className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-500 font-bold cursor-pointer"
                  >
                    إلغاء
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2.5 rounded-xl bg-emerald-600 text-white font-bold hover:bg-emerald-500 cursor-pointer transition-colors"
                  >
                    حفظ الفئة
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* --- FORBIDDEN DELETION DIALOG --- */}
      <AnimatePresence>
        {forbiddenDelete && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-rose-200 dark:border-rose-950 p-6 w-full max-w-sm shadow-2xl text-center font-sans"
            >
              <div className="w-12 h-12 rounded-full bg-rose-50 dark:bg-rose-950/40 flex items-center justify-center mx-auto text-rose-600 mb-4 animate-bounce">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-slate-850 dark:text-slate-100 text-sm mb-2">عذراً، لا يمكن حذف الفئة!</h3>
              <p className="text-slate-500 dark:text-slate-400 text-xs mb-6 leading-relaxed">
                الفئة <span className="font-bold text-rose-600">"{forbiddenDelete.catName}"</span> تحتوي حالياً على <span className="font-bold text-slate-800 dark:text-slate-100 font-mono text-sm">{forbiddenDelete.count}</span> دواء مسجل. يمنع النظام حذف الفئة وهي مأهولة بالأدوية، يرجى نقل الأدوية أولاً إلى فئة أخرى أو حذفها قبل إتمام هذه العملية.
              </p>
              
              <button
                onClick={() => setForbiddenDelete(null)}
                className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold cursor-pointer"
              >
                فهمت ذلك
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* --- CONFIRM DELETION MODAL --- */}
      <AnimatePresence>
        {showDeleteConfirm && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 w-full max-w-sm shadow-2xl text-center font-sans"
            >
              <div className="w-12 h-12 rounded-full bg-rose-50 dark:bg-rose-950 flex items-center justify-center mx-auto text-rose-600 mb-4">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-slate-800 dark:text-slate-100 text-sm mb-2">تأكيد حذف الفئة الفارغة</h3>
              <p className="text-slate-500 dark:text-slate-400 text-xs mb-6">
                هل أنت متأكد من حذف فئة الأدوية <span className="font-bold text-slate-800 dark:text-slate-100">"{showDeleteConfirm.name}"</span>؟ هذه الخطوة نهائية ولا يمكن التراجع عنها.
              </p>
              
              <div className="flex items-center gap-3 justify-center">
                <button
                  onClick={() => setShowDeleteConfirm(null)}
                  className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-500 text-xs font-semibold cursor-pointer hover:bg-slate-50"
                >
                  إلغاء
                </button>
                <button
                  onClick={handleConfirmDelete}
                  className="px-4 py-2 rounded-xl bg-rose-600 text-white text-xs font-semibold hover:bg-rose-500 cursor-pointer"
                >
                  نعم، احذف الفئة
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* --- EDIT DRUG MODAL INSIDE CATEGORIES --- */}
      <AnimatePresence>
        {showDrugModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 w-full max-w-md shadow-2xl"
            >
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3 mb-4">
                <h3 className="font-bold text-slate-800 dark:text-slate-100 text-base">
                  تعديل معلومات الدواء داخل الفئة
                </h3>
                <button
                  onClick={() => setShowDrugModal(false)}
                  className="p-1 rounded-lg hover:bg-slate-100 text-slate-500"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSaveDrug} className="space-y-4 text-xs font-sans">
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">الاسم التجاري للدواء (مطلوب):</label>
                  <input
                    type="text"
                    required
                    value={drugCommName}
                    onChange={(e) => setDrugCommName(e.target.value)}
                    className="w-full py-2.5 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">الاسم العلمي للدواء (مطلوب):</label>
                  <input
                    type="text"
                    required
                    value={drugSciName}
                    onChange={(e) => setDrugSciName(e.target.value)}
                    className="w-full py-2.5 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">الشركة المصنعة:</label>
                  <input
                    type="text"
                    value={drugManufacturer}
                    onChange={(e) => setDrugManufacturer(e.target.value)}
                    className="w-full py-2.5 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div className="flex items-center gap-3 pt-2 justify-end">
                  <button
                    type="button"
                    onClick={() => setShowDrugModal(false)}
                    className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-500 font-bold cursor-pointer"
                  >
                    إلغاء
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2.5 rounded-xl bg-emerald-600 text-white font-bold hover:bg-emerald-500 cursor-pointer transition-colors"
                  >
                    حفظ التغييرات
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* --- CONFIRM DRUG DELETION MODAL --- */}
      <AnimatePresence>
        {showDrugDeleteConfirm && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 w-full max-w-sm shadow-2xl text-center font-sans"
            >
              <div className="w-12 h-12 rounded-full bg-rose-50 dark:bg-rose-950 flex items-center justify-center mx-auto text-rose-600 mb-4">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-slate-800 dark:text-slate-100 text-sm mb-2">تأكيد حذف الدواء</h3>
              <p className="text-slate-500 dark:text-slate-400 text-xs mb-6">
                هل أنت متأكد من حذف الدواء <span className="font-bold text-slate-800 dark:text-slate-100">"{showDrugDeleteConfirm.commercialName}"</span> من النظام بالكامل؟ لا يمكن التراجع عن هذه الخطوة.
              </p>
              
              <div className="flex items-center gap-3 justify-center">
                <button
                  onClick={() => setShowDrugDeleteConfirm(null)}
                  className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-500 text-xs font-semibold cursor-pointer hover:bg-slate-50"
                >
                  إلغاء
                </button>
                <button
                  onClick={handleConfirmDeleteDrug}
                  className="px-4 py-2 rounded-xl bg-rose-600 text-white text-xs font-semibold hover:bg-rose-500 cursor-pointer"
                >
                  نعم، احذف الدواء
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Toast Alert */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className={`fixed bottom-6 right-6 z-50 px-5 py-3.5 rounded-2xl shadow-xl flex items-center gap-2.5 border text-xs max-w-sm ${
              toast.type === "success"
                ? "bg-emerald-50 border-emerald-100 dark:bg-emerald-950/90 dark:border-emerald-900 text-emerald-800 dark:text-emerald-350"
                : "bg-rose-50 border-rose-100 dark:bg-rose-950/90 dark:border-rose-900 text-rose-800 dark:text-rose-350"
            }`}
          >
            <CheckCircle className="w-5 h-5 shrink-0 text-emerald-500" />
            <span className="font-semibold leading-relaxed">{toast.text}</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
