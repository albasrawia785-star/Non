/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Users,
  Plus,
  Pencil,
  Trash2,
  Search,
  DollarSign,
  UserCheck,
  X,
  CheckCircle,
  AlertTriangle,
  Receipt,
  MapPin,
  Phone
} from "lucide-react";
import { IndexedDBService } from "../db/indexedDB";
import { Customer, SaleInvoice } from "../types";

interface CustomersViewProps {
  currency: string;
}

export default function CustomersView({ currency }: CustomersViewProps) {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [sales, setSales] = useState<SaleInvoice[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  // Form / Modal States
  const [showFormModal, setShowFormModal] = useState(false);
  const [editingCust, setEditingCust] = useState<Customer | null>(null);
  const [showDeleteModal, setShowDeleteModal] = useState<Customer | null>(null);

  // Debt Settlement state
  const [settlingCust, setSettlingCust] = useState<Customer | null>(null);
  const [settlementAmount, setSettlementAmount] = useState(0);

  // View sales history state
  const [viewHistoryCust, setViewHistoryCust] = useState<Customer | null>(null);

  // Form fields
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [debts, setDebts] = useState<number>(0);

  // Toast
  const [toast, setToast] = useState<{ text: string; type: "success" | "error" } | null>(null);

  const showToast = (text: string, type: "success" | "error" = "success") => {
    setToast({ text, type });
    setTimeout(() => setToast(null), 3000);
  };

  const loadData = async () => {
    setLoading(true);
    try {
      const custs = await IndexedDBService.getAll<Customer>("customers");
      const sls = await IndexedDBService.getAll<SaleInvoice>("sales");
      setCustomers(custs);
      setSales(sls);
    } catch (err) {
      console.error(err);
      showToast("خطأ أثناء جلب بيانات العملاء", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const openAddModal = () => {
    setEditingCust(null);
    setName("");
    setPhone("");
    setAddress("");
    setDebts(0);
    setShowFormModal(true);
  };

  const openEditModal = (cust: Customer) => {
    setEditingCust(cust);
    setName(cust.name);
    setPhone(cust.phone);
    setAddress(cust.address);
    setDebts(cust.debts);
    setShowFormModal(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    try {
      const custData: Customer = {
        id: editingCust ? editingCust.id : `cust-${Date.now()}`,
        name,
        phone,
        address: address || "غير محدد",
        debts,
      };

      if (editingCust) {
        await IndexedDBService.update("customers", custData);
        showToast("تم تحديث معلومات العميل بنجاح");
      } else {
        await IndexedDBService.add("customers", custData);
        showToast("تم تسجيل العميل الجديد بنجاح");
      }

      setShowFormModal(false);
      loadData();
    } catch (err) {
      console.error(err);
      showToast("فشلت عملية حفظ بيانات العميل", "error");
    }
  };

  const handleDelete = async () => {
    if (!showDeleteModal) return;

    try {
      await IndexedDBService.delete("customers", showDeleteModal.id);
      showToast(`تم حذف العميل (${showDeleteModal.name}) من الدليل بنجاح`);
      setShowDeleteModal(null);
      loadData();
    } catch (err) {
      console.error(err);
      showToast("فشل في حذف العميل", "error");
    }
  };

  const handleSettleDebts = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settlingCust || settlementAmount <= 0) return;

    if (settlementAmount > settlingCust.debts) {
      showToast("مبلغ السداد أكبر من الديون المترتبة على العميل!", "error");
      return;
    }

    try {
      const updated = { ...settlingCust };
      updated.debts -= settlementAmount;
      await IndexedDBService.update("customers", updated);
      
      showToast(`تم استلام مبلغ ${settlementAmount.toLocaleString("ar-IQ")} د.ع وتخفيض ديون الزبون: ${settlingCust.name}`);
      setSettlingCust(null);
      setSettlementAmount(0);
      loadData();
    } catch (err) {
      console.error(err);
      showToast("حدث خطأ أثناء سداد الديون", "error");
    }
  };

  const getCustomerSalesHistory = (id: string) => {
    return sales.filter((s) => s.customerId === id);
  };

  const filteredCustomers = customers.filter(
    (cust) => {
      const q = (search || "").toLowerCase();
      return (
        (cust.name || "").toLowerCase().includes(q) ||
        (cust.phone || "").includes(search) ||
        (cust.address || "").toLowerCase().includes(q)
      );
    }
  );

  return (
    <div className="space-y-6 font-sans text-xs">
      {/* Header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100 font-sans">دليل العملاء والديون الآجلة</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 font-sans">جدولة أسماء الزبائن، ومطالعة أرصدة الذمم والديون وسجلات مشترياتهم الآجلة.</p>
        </div>
        <button
          onClick={openAddModal}
          className="flex items-center justify-center gap-1.5 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl shadow-md cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>تسجيل زبون جديد</span>
        </button>
      </div>

      {/* Search Bar */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-between">
        <div className="relative w-full max-w-sm">
          <input
            type="text"
            placeholder="ابحث بالاسم، رقم الهاتف، أو العنوان..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pr-9 pl-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
          />
          <Search className="absolute right-3 top-3 w-4 h-4 text-slate-400" />
        </div>
        <span className="text-slate-400 font-mono">إجمالي العملاء: {customers.length}</span>
      </div>

      {/* Customers List/Table */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-right border-collapse">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-850 border-b text-slate-500 dark:text-slate-400 font-bold text-xs">
                <th className="p-4">اسم الزبون الكلي</th>
                <th className="p-4">رقم الهاتف</th>
                <th className="p-4">العنوان المسجل</th>
                <th className="p-4">الذمم والديون (بالدينار)</th>
                <th className="p-4">تعداد المشتريات</th>
                <th className="p-4 text-center">الإجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
              {loading ? (
                <tr>
                  <td colSpan={6} className="p-10 text-center">
                    <div className="w-6 h-6 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
                    <span>جاري تحميل قائمة الزبائن...</span>
                  </td>
                </tr>
              ) : filteredCustomers.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-12 text-center text-slate-400">
                    لم يتم العثور على عملاء مسجلين مطابقين للبحث.
                  </td>
                </tr>
              ) : (
                filteredCustomers.map((cust) => {
                  const custSales = getCustomerSalesHistory(cust.id);
                  return (
                    <tr key={cust.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
                      <td className="p-4 font-bold text-slate-800 dark:text-slate-200">
                        {cust.name}
                      </td>
                      <td className="p-4 font-mono text-slate-600 dark:text-slate-400">
                        {cust.phone || "—"}
                      </td>
                      <td className="p-4 text-slate-500 dark:text-slate-400">
                        {cust.address}
                      </td>
                      <td className="p-4">
                        {cust.debts > 0 ? (
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-rose-600 bg-rose-50 dark:bg-rose-950/30 px-2 py-0.5 rounded-md font-mono">
                              {cust.debts.toLocaleString("ar-IQ")} {currency}
                            </span>
                            <button
                              onClick={() => setSettlingCust(cust)}
                              className="px-2 py-0.5 rounded-md border border-rose-300 text-rose-600 font-semibold hover:bg-rose-600 hover:text-white transition-colors cursor-pointer text-[10px]"
                            >
                              سداد جزء
                            </button>
                          </div>
                        ) : (
                          <span className="text-emerald-600 font-bold bg-emerald-50 dark:bg-emerald-950/30 px-2 py-0.5 rounded-md">
                            خالٍ من الديون
                          </span>
                        )}
                      </td>
                      <td className="p-4 font-mono font-semibold text-slate-600">
                        {custSales.length} فواتير
                      </td>
                      <td className="p-4">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => setViewHistoryCust(cust)}
                            className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-850 text-slate-600 dark:text-slate-450 cursor-pointer flex items-center gap-1"
                            title="سجل مشتريات الزبون"
                          >
                            <Receipt className="w-3.5 h-3.5" />
                            <span>سجل</span>
                          </button>
                          <button
                            onClick={() => openEditModal(cust)}
                            className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-850 text-slate-600 dark:text-slate-450 cursor-pointer"
                            title="تعديل"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setShowDeleteModal(cust)}
                            className="p-1.5 rounded-lg border border-rose-100 hover:bg-rose-50 text-rose-600 cursor-pointer"
                            title="حذف"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* --- ADD / EDIT CUSTOMER FORM MODAL --- */}
      <AnimatePresence>
        {showFormModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 w-full max-w-md shadow-2xl"
            >
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3 mb-4">
                <h3 className="font-bold text-slate-800 dark:text-slate-100 text-sm">
                  {editingCust ? "تعديل بيانات العميل" : "تسجيل عميل جديد في النظام"}
                </h3>
                <button onClick={() => setShowFormModal(false)} className="p-1 rounded-lg hover:bg-slate-100 text-slate-500">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSave} className="space-y-4 font-sans text-xs">
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">اسم العميل الثلاثي:</label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: محمد جاسم فيصل..."
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full py-2.5 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">رقم الهاتف (رقم الجوال):</label>
                  <input
                    type="text"
                    placeholder="مثال: 07701234567..."
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full py-2.5 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-emerald-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">عنوان العميل / السكن:</label>
                  <input
                    type="text"
                    placeholder="مثال: بغداد - الكرادة - محلة 903..."
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    className="w-full py-2.5 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1">الرصيد الدائن للبدء (ديون سابقة):</label>
                  <input
                    type="number"
                    value={debts === 0 ? "" : debts}
                    onChange={(e) => setDebts(Math.max(0, parseInt(e.target.value) || 0))}
                    className="w-full py-2.5 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-emerald-500 font-mono text-left"
                  />
                </div>

                <div className="flex items-center gap-3 pt-2 justify-end">
                  <button
                    type="button"
                    onClick={() => setShowFormModal(false)}
                    className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-500 font-bold cursor-pointer"
                  >
                    إلغاء
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2.5 rounded-xl bg-emerald-600 text-white font-bold hover:bg-emerald-500 cursor-pointer"
                  >
                    حفظ العميل
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* --- DEBT SETTLEMENT MODAL --- */}
      <AnimatePresence>
        {settlingCust && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 w-full max-w-sm shadow-2xl"
            >
              <div className="flex items-center justify-between border-b pb-3 mb-4">
                <h3 className="font-bold text-slate-800 dark:text-slate-100 text-sm">تسجيل سداد الديون الكلي/الجزئي</h3>
                <button onClick={() => setSettlingCust(null)} className="p-1 rounded-lg hover:bg-slate-100 text-slate-500">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSettleDebts} className="space-y-4">
                <p className="text-xs text-slate-500">
                  الزبون: <b className="text-slate-800 dark:text-slate-100">{settlingCust.name}</b>
                </p>
                <div className="p-3 bg-rose-50 dark:bg-rose-950/30 rounded-lg text-xs">
                  الديون الحالية الكلية: <b className="text-rose-600 font-mono text-sm">{settlingCust.debts.toLocaleString("ar-IQ")} د.ع</b>
                </div>

                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1 text-xs">المبلغ المسدد حالياً (بالدينار):</label>
                  <input
                    type="number"
                    required
                    placeholder="اكتب المبلغ المدفوع نقداً..."
                    value={settlementAmount === 0 ? "" : settlementAmount}
                    onChange={(e) => setSettlementAmount(Math.max(0, parseInt(e.target.value) || 0))}
                    className="w-full py-2.5 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:outline-none focus:border-emerald-500 font-mono text-left"
                  />
                </div>

                <div className="flex items-center gap-3 pt-2 justify-end">
                  <button
                    type="button"
                    onClick={() => {
                      setSettlingCust(null);
                      setSettlementAmount(0);
                    }}
                    className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-500 text-xs font-semibold cursor-pointer"
                  >
                    إلغاء الأمر
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold cursor-pointer"
                  >
                    تسجيل القبض والسداد
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* --- CUSTOMER SALES HISTORY LIST OVERLAY --- */}
      <AnimatePresence>
        {viewHistoryCust && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 w-full max-w-lg shadow-2xl my-8 max-h-[85vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between border-b pb-3 mb-4">
                <h3 className="font-bold text-slate-850 dark:text-slate-150 text-sm">أرشيف فواتير الزبون: {viewHistoryCust.name}</h3>
                <button onClick={() => setViewHistoryCust(null)} className="p-1 rounded-lg hover:bg-slate-100 text-slate-500">
                  <X className="w-5 h-5" />
                </button>
              </div>

              {getCustomerSalesHistory(viewHistoryCust.id).length === 0 ? (
                <div className="py-8 text-center text-slate-400">
                  لا توجد فواتير مبيعات مسجلة لهذا العميل في النظام حالياً.
                </div>
              ) : (
                <div className="space-y-3">
                  {getCustomerSalesHistory(viewHistoryCust.id).map((inv) => (
                    <div key={inv.id} className="p-3 border rounded-xl bg-slate-50 dark:bg-slate-800/40 text-xs font-sans space-y-2">
                      <div className="flex justify-between font-bold">
                        <span className="font-mono text-slate-800 dark:text-slate-200">{inv.invoiceNumber}</span>
                        <span className="text-slate-400">{new Date(inv.date).toLocaleDateString("ar-IQ")}</span>
                      </div>
                      
                      {/* Products */}
                      <div className="text-[10px] space-y-1 text-slate-500">
                        {inv.items.map((it, i) => (
                          <div key={i} className="flex justify-between">
                            <span>{it.commercialName} × {it.quantity} علبة</span>
                            <span className="font-mono font-bold">{it.total.toLocaleString("ar-IQ")} د.ع</span>
                          </div>
                        ))}
                      </div>

                      <div className="flex justify-between border-t border-dashed border-slate-200 dark:border-slate-700 pt-2 font-bold text-slate-800 dark:text-slate-200 text-right">
                        <span>قيمة الفاتورة الكلية:</span>
                        <span className="text-emerald-600 font-mono">{inv.total.toLocaleString("ar-IQ")} د.ع</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              <button
                onClick={() => setViewHistoryCust(null)}
                className="w-full mt-6 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold cursor-pointer text-xs"
              >
                إغلاق
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* --- DELETE CONFIRM MODAL --- */}
      <AnimatePresence>
        {showDeleteModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 w-full max-w-sm shadow-2xl text-center"
            >
              <div className="w-12 h-12 rounded-full bg-rose-50 dark:bg-rose-950 flex items-center justify-center mx-auto text-rose-600 mb-4 animate-bounce">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-slate-800 dark:text-slate-100 text-sm mb-2">تأكيد حذف العميل من الدليل</h3>
              <p className="text-slate-500 dark:text-slate-400 text-xs mb-6">
                هل أنت متأكد من حذف معلومات العميل <span className="font-bold text-slate-800 dark:text-slate-100">"{showDeleteModal.name}"</span>؟ سيتم محو حسابه ديونه وهاتفه نهائياً.
              </p>
              
              <div className="flex items-center gap-3 justify-center">
                <button
                  onClick={() => setShowDeleteModal(null)}
                  className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-500 text-xs font-semibold cursor-pointer"
                >
                  إلغاء الأمر
                </button>
                <button
                  onClick={handleDelete}
                  className="px-4 py-2 rounded-xl bg-rose-600 text-white text-xs font-semibold hover:bg-rose-500 cursor-pointer"
                >
                  نعم، احذف العميل
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Toast */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className={`fixed bottom-6 right-6 z-50 px-5 py-3.5 rounded-2xl shadow-xl flex items-center gap-2.5 border text-xs max-w-sm ${
              toast.type === "success"
                ? "bg-emerald-50 border-emerald-100 dark:bg-emerald-950/90 dark:border-emerald-900 text-emerald-800 dark:text-emerald-350"
                : "bg-rose-50 border-rose-100 dark:bg-rose-950/90 dark:border-rose-900 text-rose-800 dark:text-rose-350"
            }`}
          >
            <CheckCircle className="w-5 h-5 shrink-0 text-emerald-500" />
            <span className="font-semibold leading-relaxed">{toast.text}</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
